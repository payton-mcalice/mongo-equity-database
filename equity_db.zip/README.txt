In order to set up the database you must change the path to the data file in write_example.ipynb.
You may also have to adjust the columns names to your specifications. Read the docstrings
for information on method parameters.

Packages:

   api -- this package holds code that connects to the mongo database.
          Objects from this package arte passed to classes the read and write to database

   db_access -- This package holds classes that interact with the mongo database.
                Provides read and write functionality

   examples -- This directory has example code which shows how to properly use the code we wrote.